import React, { useState, useEffect } from 'react';
import { User, CreditPackage, SystemSettings, SubscriptionPlan } from '../types';
import { Crown, Sparkles, Check, X, Zap, MessageSquare, Lock, Star } from 'lucide-react';

interface Props {
  user: User;
  settings?: SystemSettings;
  onUserUpdate: (user: User) => void;
}

const DEFAULT_PACKAGES: CreditPackage[] = [
  { id: 'pkg-1', name: '100 Credits', credits: 100, price: 10 },
  { id: 'pkg-2', name: '200 Credits', credits: 200, price: 20 },
  { id: 'pkg-3', name: '500 Credits', credits: 500, price: 50 },
  { id: 'pkg-4', name: '1000 Credits', credits: 1000, price: 100 },
  { id: 'pkg-5', name: '2000 Credits', credits: 2000, price: 200 },
  { id: 'pkg-6', name: '5000 Credits', credits: 5000, price: 500 },
  { id: 'pkg-7', name: '10000 Credits', credits: 10000, price: 1000 }
];

export const Store: React.FC<Props> = ({ user, settings }) => {
  // "BASIC" maps to "PRO", "ULTRA" maps to "MAX"
  const [tierType, setTierType] = useState<'BASIC' | 'ULTRA'>('BASIC'); 
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);
  
  const packages = settings?.packages || DEFAULT_PACKAGES;
  const subscriptionPlans = settings?.subscriptionPlans || [];
  
  // Set default selected plan (Prefer "Monthly" or "Popular" one)
  useEffect(() => {
    if (subscriptionPlans.length > 0 && !selectedPlanId) {
      const defaultPlan = subscriptionPlans.find(p => p.popular) || subscriptionPlans.find(p => p.name.includes('Monthly')) || subscriptionPlans[0];
      setSelectedPlanId(defaultPlan.id);
    }
  }, [subscriptionPlans]);

  const selectedPlan = subscriptionPlans.find(p => p.id === selectedPlanId);

  // NEW: Support Modal State
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [purchaseItem, setPurchaseItem] = useState<any>(null); // Plan or CreditPackage

  const handleSupportClick = (numEntry: any) => {
      if (!purchaseItem) return;
      
      const isSub = purchaseItem.duration !== undefined; // Detect if Sub Plan
      const itemName = purchaseItem.name;
      const price = isSub 
          ? (tierType === 'BASIC' ? purchaseItem.basicPrice : purchaseItem.ultraPrice)
          : purchaseItem.price;
      
      const features = isSub 
          ? (tierType === 'BASIC' ? 'MCQ + Notes (Pro)' : 'PDF + Videos + AI Studio (Max)')
          : `${purchaseItem.credits} Credits`;

      const message = `Hello Admin, I want to buy:\n\nItem: ${itemName} ${isSub ? `(${tierType === 'BASIC' ? 'PRO' : 'MAX'})` : ''}\nPrice: ₹${price}\nUser ID: ${user.id}\nDetails: ${features}\n\nPlease share payment details.`;
      
      window.open(`https://wa.me/91${numEntry.number}?text=${encodeURIComponent(message)}`, '_blank');
      setShowSupportModal(false);
  };

  const initiatePurchase = (item: any) => {
      setPurchaseItem(item);
      setShowSupportModal(true);
  };

  if (settings?.isPaymentEnabled === false) {
    return (
      <div className="animate-in fade-in zoom-in duration-300 pb-10">
        <div className="bg-slate-900 p-10 rounded-3xl border border-slate-800 text-center shadow-2xl">
          <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner border border-slate-700">
            <Lock size={40} className="text-slate-500" />
          </div>
          <h3 className="text-2xl font-black text-slate-200 mb-2">Store Locked</h3>
          <p className="text-slate-500 font-medium max-w-xs mx-auto leading-relaxed">
            {settings.paymentDisabledMessage || "Purchases are currently disabled by the Admin. Please check back later."}
          </p>
        </div>
      </div>
    );
  }

  // Derived Data
  const featuresList = tierType === 'BASIC' 
    ? [
        'Daily Login Bonus: 10 Credits/Day',
        'Full MCQs Unlocked (Unlimited)',
        'Premium Notes (Standard)',
        'AI Videos (2D Basic)',
        'Detailed MCQ Analysis',
        'Spin Wheel (5 Spins/Day)'
      ] 
    : [
        'Daily Login Bonus: 20 Credits/Day',
        'Everything in Basic Unlocked',
        'Premium Notes (Deep Dive)',
        'AI Videos (2D + 3D Deep Dive)',
        'Unlimited AI Studio Access',
        'Spin Wheel (Unlimited)'
      ];

  const currentPrice = selectedPlan 
    ? (tierType === 'BASIC' ? selectedPlan.basicPrice : selectedPlan.ultraPrice)
    : 0;

  // Helper to sort plans logically (Weekly -> Monthly -> Quarterly -> Yearly -> Lifetime)
  const sortedPlans = [...subscriptionPlans].sort((a, b) => {
      const getWeight = (p: SubscriptionPlan) => {
          const name = p.name.toLowerCase();
          if (name.includes('week')) return 1;
          if (name.includes('month') && !name.includes('3')) return 2;
          if (name.includes('quarter') || name.includes('3 month')) return 3;
          if (name.includes('year')) return 4;
          if (name.includes('life')) return 5;
          return 6;
      };
      return getWeight(a) - getWeight(b);
  });

  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-300 pb-24 relative min-h-screen bg-black text-white font-sans">
      
      {/* SUPPORT CHANNEL SELECTOR MODAL */}
      {showSupportModal && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
              <div className="bg-slate-900 rounded-3xl w-full max-w-sm shadow-2xl overflow-hidden border border-slate-800">
                  <div className="bg-gradient-to-r from-cyan-600 to-blue-600 p-4 text-white text-center">
                      <h3 className="font-black text-lg flex items-center justify-center gap-2">
                          <MessageSquare size={20} /> Select Support Channel
                      </h3>
                      <p className="text-xs text-cyan-100 mt-1">Choose a number to proceed with payment</p>
                  </div>
                  <div className="p-4 space-y-3">
                      {(settings?.paymentNumbers || [{id: 'def', name: 'Main Support', number: '8227070298', dailyClicks: 0}]).map((num) => {
                          const totalClicks = settings?.paymentNumbers?.reduce((acc, curr) => acc + (curr.dailyClicks || 0), 0) || 1;
                          const traffic = Math.round(((num.dailyClicks || 0) / totalClicks) * 100);
                          const isGreen = traffic < 30;

                          return (
                              <button 
                                  key={num.id}
                                  onClick={() => handleSupportClick(num)}
                                  className="w-full bg-slate-800 p-3 rounded-xl border border-slate-700 flex justify-between items-center hover:bg-slate-700 hover:border-cyan-500/50 transition-all group"
                              >
                                  <div className="flex items-center gap-3">
                                      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${isGreen ? 'bg-green-600' : 'bg-orange-500'}`}>
                                          {num.name.charAt(0)}
                                      </div>
                                      <div className="text-left">
                                          <p className="font-bold text-slate-200 text-sm group-hover:text-cyan-400">{num.name}</p>
                                          <p className="text-[10px] text-slate-500">{isGreen ? '✅ Fast Response' : '⚠️ High Traffic'}</p>
                                      </div>
                                  </div>
                                  <div className="text-right">
                                      <span className={`text-xs font-black ${isGreen ? 'text-green-500' : 'text-orange-500'}`}>{traffic}% Busy</span>
                                  </div>
                              </button>
                          );
                      })}
                  </div>
                  <div className="p-4 bg-slate-800 border-t border-slate-700 text-center">
                      <button onClick={() => setShowSupportModal(false)} className="text-slate-400 font-bold text-sm hover:text-white">Cancel</button>
                  </div>
              </div>
          </div>
      )}

      {/* --- PERPLEXITY STYLE STORE --- */}
      <div className="max-w-md mx-auto pt-8 px-4">
          
          {/* HEADER ICON */}
          <div className="flex justify-center mb-4">
              <Sparkles size={40} className="text-slate-400 opacity-80" strokeWidth={1.5} />
          </div>

          {/* TITLE & SUBTITLE */}
          <div className="text-center mb-8">
              <h2 className="text-4xl font-serif text-white tracking-tight mb-2">Select your plan</h2>
              <p className="text-slate-400 text-sm font-medium">Unlock your full potential today</p>
          </div>

          {/* TOGGLE: PRO vs MAX */}
          <div className="flex justify-center mb-8">
              <div className="bg-slate-900/50 p-1 rounded-full border border-slate-800 flex relative w-64 h-12">
                  <button 
                      onClick={() => setTierType('BASIC')}
                      className={`flex-1 rounded-full text-sm font-bold transition-all z-10 font-serif tracking-wide ${
                          tierType === 'BASIC' 
                          ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/20' 
                          : 'text-slate-400 hover:text-white'
                      }`}
                  >
                      Basic
                  </button>
                  <button 
                      onClick={() => setTierType('ULTRA')}
                      className={`flex-1 rounded-full text-sm font-bold transition-all z-10 font-serif tracking-wide flex items-center justify-center gap-2 ${
                          tierType === 'ULTRA' 
                          ? 'bg-white text-black shadow-lg' 
                          : 'text-slate-400 hover:text-white'
                      }`}
                  >
                      Ultra
                  </button>
              </div>
          </div>

          {/* FEATURES LIST */}
          <div className="mb-10 pl-2">
             <ul className="space-y-4">
                 {featuresList.map((feat, i) => (
                     <li key={i} className="flex items-start gap-3 text-sm text-slate-300 font-medium">
                         <Check size={18} className="text-slate-500 shrink-0 mt-0.5" strokeWidth={3} />
                         <span className="leading-snug">{feat}</span>
                     </li>
                 ))}
             </ul>
          </div>

          {/* PRICING CARDS - DYNAMIC GRID */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              {sortedPlans.map(plan => {
                  const isSelected = selectedPlanId === plan.id;
                  const price = tierType === 'BASIC' ? plan.basicPrice : plan.ultraPrice;
                  const originalPrice = tierType === 'BASIC' ? plan.basicOriginalPrice : plan.ultraOriginalPrice;
                  const isPopular = plan.popular;

                  return (
                      <button
                          key={plan.id}
                          onClick={() => setSelectedPlanId(plan.id)}
                          className={`p-5 rounded-2xl border text-left transition-all relative group flex flex-col justify-between h-36 ${
                              isSelected 
                                ? 'bg-[#18181b] border-cyan-500 shadow-[0_0_0_1px_rgba(6,182,212,1)]' 
                                : 'bg-[#0f0f11] border-slate-800 hover:border-slate-700'
                          }`}
                      >
                          {isSelected && (
                              <div className="absolute -top-2 -right-2 bg-cyan-500 text-black rounded-full p-1 shadow-lg z-10">
                                  <Check size={12} strokeWidth={4} />
                              </div>
                          )}

                          {isPopular && (
                              <div className="absolute -top-2 left-1/2 -translate-x-1/2 bg-amber-500 text-black text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full shadow-lg z-10 flex items-center gap-1">
                                  <Star size={8} fill="black" /> Popular
                              </div>
                          )}
                          
                          {/* Top Part */}
                          <div className="w-full">
                              <span className={`font-bold text-sm block mb-1 ${isSelected ? 'text-cyan-400' : 'text-slate-200'}`}>
                                  {plan.name}
                              </span>
                              <span className="text-xs text-slate-500">{plan.duration}</span>
                          </div>

                          {/* Bottom Part */}
                          <div>
                              <div className="flex items-baseline gap-2">
                                  <span className="text-xl font-serif text-white">₹{price.toLocaleString('en-IN')}</span>
                                  {originalPrice && (
                                      <span className="text-xs text-slate-500 line-through">₹{originalPrice}</span>
                                  )}
                              </div>
                              {originalPrice && (
                                  <p className="text-[10px] text-green-500 font-bold mt-1">
                                      {Math.round(((originalPrice - price) / originalPrice) * 100)}% OFF
                                  </p>
                              )}
                          </div>
                      </button>
                  );
              })}
              
              {subscriptionPlans.length === 0 && (
                  <div className="col-span-2 text-center py-8 text-slate-500">
                      No plans available at the moment.
                  </div>
              )}
          </div>

          {/* ACTION BUTTON */}
          <button
                 onClick={() => selectedPlan && initiatePurchase(selectedPlan)}
                 disabled={!selectedPlan}
                 className={`w-full py-4 rounded-full font-bold text-sm tracking-wide shadow-lg transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed ${
                     tierType === 'BASIC' 
                        ? 'bg-cyan-500 text-black hover:bg-cyan-400 shadow-cyan-500/20' 
                        : 'bg-white text-black hover:bg-slate-200 shadow-white/10'
                 }`}
             >
                 Get {selectedPlan ? selectedPlan.name : 'Plan'} ({tierType === 'BASIC' ? 'Pro' : 'Max'})
          </button>


          {/* COIN STORE (Minimalist) */}
          <div className="mt-16 border-t border-slate-900 pt-8">
              <div className="flex items-center justify-between mb-6">
                  <span className="text-slate-400 font-serif text-lg">Top-up Coins</span>
                  <Zap size={20} className="text-amber-500" />
              </div>

              <div className="grid grid-cols-3 gap-3">
                  {packages.slice(0, 6).map(pkg => (
                      <button
                          key={pkg.id}
                          onClick={() => initiatePurchase(pkg)}
                          className="bg-slate-900 border border-slate-800 p-3 rounded-xl hover:bg-slate-800 hover:border-slate-700 transition-all text-center group"
                      >
                          <p className="text-white font-bold text-md mb-1">{pkg.credits}</p>
                          <p className="text-slate-500 text-[10px] uppercase font-bold">₹{pkg.price}</p>
                      </button>
                  ))}
              </div>
          </div>

      </div>
    </div>
  );
};
